package kr.hs.study.bootprj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootPrjApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootPrjApplication.class, args);
    }

}
