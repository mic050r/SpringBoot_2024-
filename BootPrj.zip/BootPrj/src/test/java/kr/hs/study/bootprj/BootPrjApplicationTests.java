package kr.hs.study.bootprj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootPrjApplicationTests {

    @Test
    void contextLoads() {
    }

}
