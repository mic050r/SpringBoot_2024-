package kr.hs.study.firstDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstDbApplication.class, args);
	}

}
