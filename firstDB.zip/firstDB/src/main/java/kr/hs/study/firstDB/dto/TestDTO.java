package kr.hs.study.firstDB.dto;

import lombok.Data;

@Data
public class TestDTO {
    private int id;
    private String name;
}
