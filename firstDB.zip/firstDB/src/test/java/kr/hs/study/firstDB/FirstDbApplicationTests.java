package kr.hs.study.firstDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
